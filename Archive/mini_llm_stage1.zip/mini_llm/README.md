# mini_llm

A small decoder-only language model trained from scratch on FineWeb-Edu.
It's built for the course assignments (Session 9 onward) and reused across them.

| Component | Choice |
|---|---|
| Data | `HuggingFaceFW/fineweb-edu`, subset `sample-10BT`, streamed. Default: 20M train + 0.5M val tokens |
| Tokenizer | Our own byte-level BPE, 8,192 tokens. `<pad>` = 0, `<eos>` = 1 (appended after every document) |
| Model | 8 layers, D=384, 6 heads (head_dim 64), context 256, RoPE, RMSNorm, pre-norm, SwiGLU (1024) |
| Size | ~20.5M parameters untied, ~17.3M tied |

## Setup on Windows 11 (one time), from the mini_llm folder

```powershell
nvidia-smi
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install torch --index-url https://download.pytorch.org/whl/cu128
pip install -r requirements.txt
```

If activation is blocked: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
In Antigravity, select `.venv` as the Python interpreter.

## Stage 1: run order

```powershell
python check_env.py            # ends in PASS, Compute cap. sm_120
python -m data.prepare_data    # ~10-30 min: stream, train tokenizer, write data\prepared\
python -m model.model          # random-token self-test
python stage1_check.py         # real batch -> logits, every shape printed
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `CUDA not available` | CPU-only torch installed. `pip uninstall torch`, then reinstall with cu128 |
| `no kernels for sm_120` | Torch build too old. Reinstall with `cu128` or newer |
| `ModuleNotFoundError: config` | Run from the `mini_llm` folder, using `python -m data.prepare_data` |
| `train.bin not found` | Run `python -m data.prepare_data` first |
| Stream stalls or HTTP 429 | `huggingface-cli login`, then rerun with `--force` |
